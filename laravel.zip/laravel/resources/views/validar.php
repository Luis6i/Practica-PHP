<?php
//Recogemos los valores del login y las guardamos en variables
$user= $_POST['user'];
$pass= $_POST['pass'];

//Conexion a la base de datos


