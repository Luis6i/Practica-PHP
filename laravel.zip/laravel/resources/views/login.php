<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Login</title>
</head>
<body>
<div>

	<?php
		//Crear conexion con oracle
		$db="(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=88.2.227.247)(PORT=1521)) (CONNECT_DATA= (SERVICE_NAME = XE)))";
		$conn = oci_connect("LUIS", "luis", $db);

		if (!$conn) {
			$m = oci_error();
			echo $m['message'], "\n";
			exit;
		} else {
			echo "Conexion con oracle completa";
		}

		oci_close($conn);
	?>
	<center>
		<h1>Login</h1>
		<form method="POST" action="validar.php">
			<input type="text" name="user" placeholder="Usuario">
			<input type="password" name="pass" placeholder="*******">
			<input type="submit" name="Validar">
		</form>
	</center>
</div>
</body>
</html>